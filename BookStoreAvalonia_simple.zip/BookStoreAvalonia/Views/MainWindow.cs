using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;
using BookStoreAvalonia.Models;
using BookStoreAvalonia.Services;
using System.Globalization;
namespace BookStoreAvalonia.Views;
public sealed class MainWindow : Window
{
    readonly Database db = new();
    readonly StackPanel root = new() { Spacing = 12, Margin = new Thickness(22) };
    string? currentUser;
    TextBox? search;
    public MainWindow()
    {
        Title = "Книжный магазин"; Width = 1100; Height = 760; MinWidth = 760; MinHeight = 540;
        Background = Brushes.White;
        Content = new ScrollViewer { Content = root };
        ShowLogin();
    }
    static TextBlock Text(string value, int size = 16, bool bold = false) => new() { Text = value, FontSize = size, FontWeight = bold ? FontWeight.Bold : FontWeight.Normal, Foreground = Brushes.Black, TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center };
    static Button Btn(string value, Action action) { var b = new Button { Content = value, Padding = new Thickness(12,8), Margin = new Thickness(3) }; b.Click += (_,_) => action(); return b; }
    static TextBox Field(string hint, string value = "") => new() { Watermark = hint, Text = value, MinWidth = 180, Margin = new Thickness(0,3) };
    static StackPanel Row(params Control[] children) { var p = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 }; foreach(var c in children) p.Children.Add(c); return p; }
    void Clear(string heading) { root.Children.Clear(); root.Children.Add(Text(heading,28,true)); }
    async void Error(string message) { var w = new Window { Background = Brushes.White, Title = "Сообщение", Width = 430, Height = 180, Content = new TextBlock { Text = message, Margin = new Thickness(24), TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center } }; await w.ShowDialog(this); }
    void ShowLogin()
    {
        Clear("Вход в систему"); root.Children.Add(Text("Создайте аккаунт или войдите в существующий."));
        var login = Field("Логин"); var password = new TextBox { Watermark = "Пароль", PasswordChar = '●', MinWidth = 180 };
        root.Children.Add(login); root.Children.Add(password);
        root.Children.Add(Row(Btn("Войти", () => { if (db.Login(login.Text ?? "", password.Text ?? "")) { currentUser = login.Text?.Trim(); ShowCatalog(); } else Error("Неверный логин или пароль."); }), Btn("Зарегистрироваться", () => { try { if (db.Register(login.Text ?? "", password.Text ?? "")) { currentUser = login.Text?.Trim(); ShowCatalog(); } else Error("Этот логин уже занят."); } catch (Exception e) { Error(e.Message); } })));
    }
    void Menu()
    {
        root.Children.Add(Row(Btn("Каталог", ShowCatalog), Btn("Новинки", ShowNew), Btn("Статистика", ShowStats), Btn("Выход", () => { currentUser = null; ShowLogin(); })));
        root.Children.Add(Text("Пользователь: " + currentUser,12));
    }
    void ShowCatalog()
    {
        if (currentUser is null) { ShowLogin(); return; }
        Clear("Книжный магазин"); Menu();
        search = Field("Поиск: название, автор или жанр"); search.MinWidth = 380;
        search.TextChanged += (_,_) => DrawBooks();
        root.Children.Add(Row(search, Btn("+ Добавить книгу", () => EditBook(null))));
        var holder = new StackPanel { Name = "BooksHolder", Spacing = 7 };
        root.Children.Add(holder); DrawBooks();
    }
    void DrawBooks()
    {
        var holder = root.Children.OfType<StackPanel>().FirstOrDefault(x => x.Name == "BooksHolder"); if (holder is null) return;
        holder.Children.Clear(); var books = db.Books(search?.Text ?? "");
        holder.Children.Add(Text($"Найдено книг: {books.Count}",14));
        foreach (var b in books)
        {
            var details = new StackPanel { Spacing = 3, Width = 390 };
            details.Children.Add(Text(b.Title,18,true));
            details.Children.Add(Text($"{b.Author} · {b.Genre} · {b.Year} г.",13));
            details.Children.Add(Text($"Издательство: {b.Publisher} · {b.Pages} стр.",12));
            var item = Row(details, Text($"{b.Price:0.00} ₽",17,true), Text($"Продаж: {b.Sales}",13), Btn("Продать", () => { try { db.Sell(b.Id); ShowCatalog(); } catch(Exception e) { Error(e.Message); } }), Btn("Изменить", () => EditBook(b)), Btn("Удалить", () => ConfirmDelete(b)));
            item.Margin = new Thickness(0,6); holder.Children.Add(new Border { Background = new SolidColorBrush(Color.Parse("#F2F2F2")), CornerRadius = new CornerRadius(2), Padding = new Thickness(10), Child = new ScrollViewer { HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto, Content = item } });
        }
    }
    async void ConfirmDelete(Book b)
    {
        var dialog = new Window { Background = Brushes.White, Title = "Удалить книгу?", Width = 390, Height = 180 };
        var yes = false; var panel = new StackPanel { Margin = new Thickness(20), Spacing = 14 };
        panel.Children.Add(Text("Удалить «" + b.Title + "»?"));
        panel.Children.Add(Row(Btn("Удалить", () => { yes = true; dialog.Close(); }), Btn("Отмена", dialog.Close)));
        dialog.Content = panel; await dialog.ShowDialog(this); if (yes) { db.Delete(b.Id); ShowCatalog(); }
    }
    async void EditBook(Book? b)
    {
        var dialog = new Window { Background = Brushes.White, Title = b is null ? "Добавить книгу" : "Редактировать книгу", Width = 510, Height = 660 };
        var title = Field("Название",b?.Title ?? ""); var author = Field("Автор",b?.Author ?? ""); var publisher = Field("Издательство",b?.Publisher ?? "");
        var pages = Field("Количество страниц",b?.Pages.ToString() ?? ""); var genre = Field("Жанр",b?.Genre ?? ""); var year = Field("Год издания",b?.Year.ToString() ?? ""); var price = Field("Цена",b?.Price.ToString(CultureInfo.InvariantCulture) ?? "");
        var panel = new StackPanel { Margin = new Thickness(22), Spacing = 8 };
        foreach(var c in new Control[] { Text("Заполните данные книги",21,true),title,author,publisher,pages,genre,year,price }) panel.Children.Add(c);
        bool saved = false;
        panel.Children.Add(Row(Btn("Сохранить", () =>
        {
            if (string.IsNullOrWhiteSpace(title.Text) || string.IsNullOrWhiteSpace(author.Text) || string.IsNullOrWhiteSpace(publisher.Text) || string.IsNullOrWhiteSpace(genre.Text) || !int.TryParse(pages.Text,out var p) || p <= 0 || !int.TryParse(year.Text,out var y) || y < 1450 || y > DateTime.Now.Year + 1 || !decimal.TryParse((price.Text ?? "").Replace(',','.'), NumberStyles.Number, CultureInfo.InvariantCulture,out var cost) || cost < 0) { Error("Проверьте поля. Страницы должны быть больше нуля, год — корректным, цена — неотрицательной."); return; }
            try { db.Save(new Book { Id = b?.Id ?? 0, Title = title.Text.Trim(), Author = author.Text.Trim(), Publisher = publisher.Text.Trim(), Pages = p, Genre = genre.Text.Trim(), Year = y, Price = cost }); saved = true; dialog.Close(); } catch(Exception e) { Error(e.Message); }
        }), Btn("Отмена", dialog.Close)));
        dialog.Content = new ScrollViewer { Content = panel }; await dialog.ShowDialog(this); if(saved) ShowCatalog();
    }
    void ShowNew()
    {
        Clear("Новинки магазина"); Menu();
        foreach(var b in db.Books().OrderByDescending(x => x.AddedAt).Take(15)) root.Children.Add(Text($"{b.AddedAt.ToLocalTime():dd.MM.yyyy}  •  {b.Title} — {b.Author} ({b.Year}) — {b.Price:0.00} ₽"));
    }
    void ShowStats()
    {
        Clear("Статистика продаж"); Menu();
        var periods = new ComboBox { ItemsSource = new[] { "День", "Неделя", "Месяц", "Год" }, SelectedIndex = 0, Width = 180 };
        root.Children.Add(Row(Text("Период:"), periods));
        var report = new StackPanel { Spacing = 10 }; root.Children.Add(report);
        void Render()
        {
            report.Children.Clear(); var now = DateTime.Now;
            DateTime from = periods.SelectedIndex switch { 1 => now.AddDays(-7), 2 => now.AddMonths(-1), 3 => now.AddYears(-1), _ => now.Date };
            var sum = db.Summary(from); report.Children.Add(Text($"Продаж: {sum.Count}  |  Выручка: {sum.Revenue:0.00} ₽",20,true));
            foreach(var section in new[] { ("Самые продаваемые книги","title"), ("Популярные авторы","author"), ("Популярные жанры","genre") })
            {
                report.Children.Add(Text(section.Item1,19,true)); var top = db.Top(section.Item2,from);
                if(top.Count == 0) report.Children.Add(Text("За выбранный период продаж нет.",13));
                int i = 1; foreach(var x in top) report.Children.Add(Text($"{i++}. {x.Name} — {x.Count} продаж"));
            }
        }
        periods.SelectionChanged += (_,_) => Render(); Render();
    }
}
