using Microsoft.Data.Sqlite;
using BookStoreAvalonia.Models;
using System.Security.Cryptography;
namespace BookStoreAvalonia.Services;
public sealed class Database
{
    private readonly string _connectionString;
    public Database()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BookStoreAvalonia");
        Directory.CreateDirectory(dir);
        _connectionString = new SqliteConnectionStringBuilder { DataSource = Path.Combine(dir, "books.db") }.ToString();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, login TEXT NOT NULL UNIQUE, salt BLOB NOT NULL, hash BLOB NOT NULL);
            CREATE TABLE IF NOT EXISTS books (id INTEGER PRIMARY KEY, title TEXT NOT NULL, author TEXT NOT NULL, publisher TEXT NOT NULL, pages INTEGER NOT NULL, genre TEXT NOT NULL, year INTEGER NOT NULL, price TEXT NOT NULL, sales INTEGER NOT NULL DEFAULT 0, added_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS purchases (id INTEGER PRIMARY KEY, book_id INTEGER NOT NULL, title TEXT NOT NULL, author TEXT NOT NULL, genre TEXT NOT NULL, price TEXT NOT NULL, sold_at TEXT NOT NULL);
            """;
        cmd.ExecuteNonQuery();
    }
    private SqliteConnection Open() { var c = new SqliteConnection(_connectionString); c.Open(); return c; }
    public bool Register(string login, string password)
    {
        if (login.Trim().Length < 3 || password.Length < 6) throw new ArgumentException("Логин: от 3 символов; пароль: от 6 символов.");
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 120000, HashAlgorithmName.SHA256, 32);
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "INSERT INTO users(login,salt,hash) VALUES($l,$s,$h)";
        cmd.Parameters.AddWithValue("$l", login.Trim()); cmd.Parameters.AddWithValue("$s", salt); cmd.Parameters.AddWithValue("$h", hash);
        try { return cmd.ExecuteNonQuery() == 1; } catch (SqliteException e) when (e.SqliteErrorCode == 19) { return false; }
    }
    public bool Login(string login, string password)
    {
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT salt,hash FROM users WHERE login=$l"; cmd.Parameters.AddWithValue("$l", login.Trim());
        using var r = cmd.ExecuteReader(); if (!r.Read()) return false;
        var actual = Rfc2898DeriveBytes.Pbkdf2(password, (byte[])r[0], 120000, HashAlgorithmName.SHA256, 32);
        return CryptographicOperations.FixedTimeEquals(actual, (byte[])r[1]);
    }
    public List<Book> Books(string search = "")
    {
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT id,title,author,publisher,pages,genre,year,price,sales,added_at FROM books WHERE title LIKE $q OR author LIKE $q OR genre LIKE $q ORDER BY id DESC";
        cmd.Parameters.AddWithValue("$q", "%" + search + "%");
        using var r = cmd.ExecuteReader(); var list = new List<Book>();
        while (r.Read()) list.Add(new Book { Id = r.GetInt64(0), Title = r.GetString(1), Author = r.GetString(2), Publisher = r.GetString(3), Pages = r.GetInt32(4), Genre = r.GetString(5), Year = r.GetInt32(6), Price = decimal.Parse(r.GetString(7), System.Globalization.CultureInfo.InvariantCulture), Sales = r.GetInt32(8), AddedAt = DateTime.Parse(r.GetString(9), null, System.Globalization.DateTimeStyles.RoundtripKind) });
        return list;
    }
    public void Save(Book b)
    {
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = b.Id == 0 ? "INSERT INTO books(title,author,publisher,pages,genre,year,price,sales,added_at) VALUES($t,$a,$p,$pg,$g,$y,$pr,0,$d)" : "UPDATE books SET title=$t,author=$a,publisher=$p,pages=$pg,genre=$g,year=$y,price=$pr WHERE id=$id";
        cmd.Parameters.AddWithValue("$id", b.Id); cmd.Parameters.AddWithValue("$t", b.Title); cmd.Parameters.AddWithValue("$a", b.Author); cmd.Parameters.AddWithValue("$p", b.Publisher); cmd.Parameters.AddWithValue("$pg", b.Pages); cmd.Parameters.AddWithValue("$g", b.Genre); cmd.Parameters.AddWithValue("$y", b.Year); cmd.Parameters.AddWithValue("$pr", b.Price.ToString(System.Globalization.CultureInfo.InvariantCulture)); cmd.Parameters.AddWithValue("$d", DateTime.UtcNow.ToString("O")); cmd.ExecuteNonQuery();
    }
    public void Delete(long id) { using var c = Open(); using var cmd = c.CreateCommand(); cmd.CommandText = "DELETE FROM books WHERE id=$id"; cmd.Parameters.AddWithValue("$id", id); cmd.ExecuteNonQuery(); }
    public void Sell(long id)
    {
        using var c = Open(); using var tx = c.BeginTransaction();
        using var cmd = c.CreateCommand(); cmd.Transaction = tx;
        cmd.CommandText = "INSERT INTO purchases(book_id,title,author,genre,price,sold_at) SELECT id,title,author,genre,price,$now FROM books WHERE id=$id";
        cmd.Parameters.AddWithValue("$id", id); cmd.Parameters.AddWithValue("$now", DateTime.UtcNow.ToString("O"));
        if (cmd.ExecuteNonQuery() != 1) throw new InvalidOperationException("Книга не найдена.");
        cmd.CommandText = "UPDATE books SET sales=sales+1 WHERE id=$id"; cmd.ExecuteNonQuery(); tx.Commit();
    }
    public List<(string Name,long Count)> Top(string column, DateTime from, int limit = 10)
    {
        if (column is not ("title" or "author" or "genre")) throw new ArgumentException("Недопустимый параметр.");
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = $"SELECT {column}, COUNT(*) AS total FROM purchases WHERE sold_at >= $from GROUP BY {column} ORDER BY total DESC LIMIT $limit";
        cmd.Parameters.AddWithValue("$from", from.ToUniversalTime().ToString("O")); cmd.Parameters.AddWithValue("$limit", limit);
        using var r = cmd.ExecuteReader(); var list = new List<(string,long)>(); while (r.Read()) list.Add((r.GetString(0),r.GetInt64(1))); return list;
    }
    public (long Count,decimal Revenue) Summary(DateTime from)
    {
        using var c = Open(); using var cmd = c.CreateCommand(); cmd.CommandText = "SELECT price FROM purchases WHERE sold_at >= $from"; cmd.Parameters.AddWithValue("$from", from.ToUniversalTime().ToString("O"));
        using var r = cmd.ExecuteReader(); long n = 0; decimal total = 0; while (r.Read()) { n++; total += decimal.Parse(r.GetString(0), System.Globalization.CultureInfo.InvariantCulture); } return (n,total);
    }
}
