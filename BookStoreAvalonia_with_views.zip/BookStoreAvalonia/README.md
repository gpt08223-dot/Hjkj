Книжный магазин — Avalonia UI, C#, SQLite

Откройте BookStoreAvalonia.sln в Visual Studio 2022 (17.12+) с .NET 8 SDK.
Восстановите NuGet-пакеты и запустите проект клавишей F5.
Для новых версий Visual Studio также есть BookStoreAvalonia.slnx.
При первом запуске зарегистрируйте пользователя.
База данных SQLite создаётся автоматически.
